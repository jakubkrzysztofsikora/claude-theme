# Plan: Zero-Dependency Claude White-Label Theming System
## Full Open-Source Marketplace-Ready Repository

### Research Analysis Summary
The research documents a zero-dependency architecture for white-labeling Claude's interface across terminal + browser environments using:
- **Native APIs only**: CSSStyleSheet, MutationObserver, FontFace API, Node.js fs/path
- **Three core components**: SKILL.md spec, build-theme.js CLI compiler, inject.js browser injector
- **Design token system**: CSS custom properties on :root for color/typography/logo overrides
- **Bidirectional bridge**: Claude Code terminal ↔ Chrome via Native Messaging API
- **Security model**: N=0 dependencies = zero supply-chain attack surface

---

## Stage 1: Repository Foundation & Core Engine
**Skills**: vibecoding-general-swarm
**Agents**:
- `Repo_Architect`: Design full directory structure, README, LICENSE, package.json (zero-deps), .gitignore
- `Core_Engineer`: Implement build-theme.js CLI compiler, inject.js browser injector, manifest.json
- `Skill_Spec_Writer`: Create SKILL.md specification with /apply-theme, /list-themes, /preview-theme commands
- `Theme_Schema_Designer`: Design JSON theme schema with validation

## Stage 2: Theme Marketplace System
**Skills**: vibecoding-general-swarm, vibecoding-webapp-swarm
**Agents**:
- `Marketplace_Dev`: Build GitHub Pages Jekyll/Vite marketplace site
- `Theme_Gallery_Designer`: Create theme card UI, preview system, search/filter
- `Submission_System_Dev`: Build theme submission workflow (PR-based + validation)

## Stage 3: Sample Themes Collection
**Agents**:
- `Theme_Creator_Parallel_x5`: Create 8+ diverse sample themes (dark, light, high-contrast, branded, minimalist, nature-inspired, cyberpunk, warm-neutral)

## Stage 4: Documentation & DevEx
**Agents**:
- `Docs_Writer`: README, CONTRIBUTING, theme authoring guide, API reference
- `DevEx_Engineer`: CLI help system, theme validation, preview server

## Stage 5: CI/CD & Deployment
**Agents**:
- `CICD_Engineer`: GitHub Actions for theme validation, marketplace deploy, PR checks
- `Deploy_Engineer`: Deploy marketplace to GitHub Pages

---

## Deliverables
1. Complete repository at `/mnt/agents/output/claude-whitelabel-themes/`
2. Working core plugin (zero dependencies)
3. GitHub Pages marketplace with theme gallery
4. 8+ sample themes with previews
5. Full documentation
6. CI/CD pipeline
