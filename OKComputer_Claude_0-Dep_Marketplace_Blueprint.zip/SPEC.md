# SPEC.md — Zero-Dependency Claude White-Label Theming System

## 1. Overview

A zero-dependency white-label theming plugin for Claude that enables complete visual customization of both the terminal CLI and browser UI. The system uses only native Node.js and browser APIs — zero npm dependencies, zero supply-chain attack surface.

## 2. Theme JSON Schema (v1)

Every theme is a single JSON file following this schema:

```json
{
  "$schema": "https://claude-themes.dev/schema/v1/theme.json",
  "name": "Theme Display Name",
  "id": "theme-kebab-case-id",
  "version": "1.0.0",
  "author": "Author Name",
  "description": "Short description of the theme.",
  "license": "MIT",
  "tags": ["dark", "minimal", "blue"],
  "preview": {
    "primary": "#0192F4",
    "secondary": "#CC6B3C",
    "background": "#0A0A0A",
    "surface": "#141414",
    "text": "#E0E0E0"
  },
  "tokens": {
    "color": {
      "brandPrimary": "#CC6B3C",
      "brandAccent": "#D97757",
      "background": "#FAFAF8",
      "surface": "#F4F3F1",
      "surfaceHover": "#EAE9E7",
      "textPrimary": "#2C2B29",
      "textSecondary": "#6B6A69",
      "textMuted": "#9B9A98",
      "border": "#E0DFDB",
      "success": "#2D8A4E",
      "warning": "#D4A017",
      "error": "#C73E3A",
      "userMessageText": "#0192F4"
    },
    "typography": {
      "fontFamily": "Inter",
      "fontUrl": "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap",
      "fontWeights": {
        "normal": 400,
        "medium": 500,
        "semibold": 600,
        "bold": 700
      }
    },
    "logo": {
      "type": "svg",
      "content": "<svg>...</svg>",
      "viewBox": "0 0 32 32"
    },
    "favicon": {
      "type": "emoji",
      "value": "🎨"
    }
  },
  "terminal": {
    "userColor": "#0192F4",
    "assistantColor": "#E0E0E0",
    "systemColor": "#9B9A98",
    "errorColor": "#C73E3A",
    "successColor": "#2D8A4E",
    "backgroundColor": "#0A0A0A",
    "promptColor": "#CC6B3C"
  }
}
```

### Required Fields
- `name`, `id`, `version`, `author`, `description` — Metadata
- `preview` — 5 colors for marketplace card rendering (no external assets needed)
- `tokens.color` — At minimum: `brandPrimary`, `background`, `surface`, `textPrimary`, `userMessageText`
- All other fields are optional with sensible fallbacks

## 3. Core Components

### 3.1 build-theme.js (Node.js CLI Compiler)
- **Location**: `.claude/skills/whitelabel-theme/build-theme.js`
- **Purpose**: Reads a theme JSON file, compiles browser extension assets, updates terminal settings
- **Zero dependencies**: Uses only `fs`, `path`, `crypto`, `child_process` (native Node.js modules)
- **CLI interface**:
  ```
  node build-theme.js <command> [options]
  
  Commands:
    apply <theme-file>     Apply a theme (compile + activate)
    compile <theme-file>   Compile theme to extension/ folder
    list                   List installed themes
    validate <theme-file>  Validate theme JSON against schema
    preview <theme-file>   Start local preview server
    init <theme-name>      Create a new theme template
  ```
- **Outputs**:
  - `extension/manifest.json` — Chrome extension manifest
  - `extension/inject.js` — Compiled injector script with theme tokens baked in
  - `extension/styles.css` — Compiled CSS variable overrides
  - `extension/icons/` — Generated favicon/icon assets
  - Updates `~/.claude/settings.json` for terminal theming

### 3.2 inject.js (Browser Injector)
- **Location**: Compiled to `extension/inject.js` by build-theme.js
- **Purpose**: Runs in Claude's web UI to apply theme tokens dynamically
- **Zero dependencies**: Uses only native browser APIs
- **Key mechanisms**:
  - `CSSStyleSheet` API to inject CSS custom properties on `:root`
  - `FontFace` API to load custom fonts from CDN at runtime
  - `MutationObserver` to watch for DOM changes and re-apply logo/branding
  - `chrome.runtime.onMessage` to listen for theme update commands from CLI
- **Must handle**: SPA navigation, React re-renders, theme switching without page reload

### 3.3 manifest.json (Chrome Extension)
- **Location**: Compiled to `extension/manifest.json` by build-theme.js
- **Manifest V3 format
- **Permissions**: `activeTab`, `scripting`, `storage`
- **Host permissions**: `https://claude.ai/*`, `https://*.claude.ai/*`
- **Content script**: Injects inject.js on matching Claude domains
- **Background service worker**: Handles messaging between CLI and content script

### 3.4 SKILL.md (Claude Code Skill Spec)
- **Location**: `.claude/skills/whitelabel-theme/SKILL.md`
- **Purpose**: Registers slash commands in Claude Code
- **Commands**:
  - `/apply-theme <theme-id>` — Apply a theme
  - `/list-themes` — List all available themes
  - `/preview-theme <theme-id>` — Open preview in browser
  - `/reset-theme` — Reset to default Claude styling

## 4. Directory Structure

```
claude-whitelabel-themes/
├── .claude/
│   └── skills/
│       └── whitelabel-theme/
│           ├── SKILL.md           # Claude Code skill specification
│           └── build-theme.js     # CLI compiler (zero deps)
├── themes/                        # Theme gallery (submittable via PR)
│   ├── schema.json                # JSON Schema for theme validation
│   ├── README.md                  # Theme authoring guide
│   ├── dark/
│   │   └── theme.json
│   ├── light/
│   │   └── theme.json
│   ├── high-contrast/
│   │   └── theme.json
│   ├── branded/
│   │   └── theme.json
│   ├── minimalist/
│   │   └── theme.json
│   ├── nature/
│   │   └── theme.json
│   ├── cyberpunk/
│   │   └── theme.json
│   └── warm-neutral/
│       └── theme.json
├── extension/                     # Compiled extension (gitignored, generated)
│   ├── manifest.json
│   ├── inject.js
│   ├── styles.css
│   └── icons/
├── scripts/                       # CI/CD and utility scripts
│   ├── validate-theme.js          # Theme validation script
│   ├── generate-preview.js        # Generate preview images
│   └── build-marketplace.js       # Build marketplace data JSON
├── marketplace/                   # GitHub Pages marketplace site
│   ├── index.html
│   ├── src/
│   │   ├── main.tsx
│   │   ├── App.tsx
│   │   ├── components/
│   │   │   ├── ThemeCard.tsx
│   │   │   ├── ThemePreview.tsx
│   │   │   ├── ThemeFilter.tsx
│   │   │   ├── Header.tsx
│   │   │   └── Footer.tsx
│   │   ├── data/
│   │   │   └── themes.json        # Generated from themes/ folder
│   │   └── styles/
│   │       └── index.css
│   ├── package.json
│   ├── vite.config.ts
│   └── tsconfig.json
├── docs/
│   ├── GETTING_STARTED.md
│   ├── THEME_AUTHORING.md
│   ├── API_REFERENCE.md
│   └── ARCHITECTURE.md
├── .github/
│   └── workflows/
│       ├── validate-themes.yml    # PR validation
│       ├── build-marketplace.yml  # Deploy marketplace
│       └── release.yml            # Release automation
├── README.md
├── CONTRIBUTING.md
├── LICENSE
├── package.json                   # Root (zero deps, scripts only)
└── .gitignore
```

## 5. Marketplace (GitHub Pages)

### 5.1 Purpose
Static site deployed to GitHub Pages for browsing, previewing, and downloading themes.

### 5.2 Features
- **Theme Gallery**: Card grid showing all themes with color preview swatches
- **Theme Detail Page**: Full preview with all tokens, download button, install instructions
- **Filter/Search**: By tags (dark, light, minimal, etc.), author, search query
- **Submit Theme**: Link to CONTRIBUTING.md with PR instructions
- **Live Preview**: CSS-only preview of how theme colors look in a mock Claude UI
- **No backend**: Pure static site, reads themes from generated JSON

### 5.3 Tech Stack
- React 19 + TypeScript + Vite + Tailwind CSS (per webapp-building-swarm)
- Static generation: `npm run build` outputs to `dist/` for GitHub Pages
- Theme data: Generated by `scripts/build-marketplace.js` which reads all `themes/*/theme.json` files and outputs `marketplace/src/data/themes.json`

### 5.4 Theme Submission Flow (via PR)
1. User creates a new folder in `themes/`
2. Adds `theme.json` following schema
3. Opens PR
4. GitHub Actions validates theme JSON against schema
5. On merge, marketplace rebuilds automatically
6. New theme appears on GitHub Pages within minutes

## 6. CI/CD Pipeline

### 6.1 validate-themes.yml
- Triggers on: PRs affecting `themes/**`
- Steps:
  1. Checkout code
  2. Run `node scripts/validate-theme.js themes/*/theme.json`
  3. Fail PR if any theme is invalid
  4. Generate preview images for new/changed themes

### 6.2 build-marketplace.yml
- Triggers on: push to `main` affecting `themes/**` or `marketplace/**`
- Steps:
  1. Checkout code
  2. Run `node scripts/build-marketplace.js`
  3. Build marketplace site: `cd marketplace && npm run build`
  4. Deploy `marketplace/dist` to GitHub Pages

## 7. Sample Themes (8 Themes)

### 7.1 dark — "Midnight Forge"
Dark theme with deep charcoal backgrounds and electric blue accents. Inspired by modern IDE dark modes.

### 7.2 light — "Clean Slate"
Clean, minimal light theme with subtle grays and a professional blue accent. Maximum readability.

### 7.3 high-contrast — "A11y First"
WCAG AAA compliant high-contrast theme designed for accessibility. Pure black on white with vivid accent colors.

### 7.4 branded — "Terracotta Pro"
Warm terracotta and clay-inspired brand colors. Professional, distinctive, earthy.

### 7.5 minimalist — "Mono Space"
Strictly monochromatic. No accent colors — pure grayscale typography-first design.

### 7.6 nature — "Forest Canopy"
Deep greens, moss tones, warm bark browns. Organic and calming.

### 7.7 cyberpunk — "Neon District"
Hot pinks, electric cyans, deep purples. High-energy cyberpunk aesthetic.

### 7.8 warm-neutral — "Parchment"
Warm creams, soft beiges, sepia tones. Easy on the eyes for long sessions.

## 8. Interface Contracts

### build-theme.js CLI
```javascript
// apply(themePath: string): void
// compile(themePath: string): { manifestPath, injectPath, stylePath }
// list(): ThemeMeta[]
// validate(themePath: string): { valid: boolean, errors: string[] }
// preview(themePath: string, port?: number): void
// init(themeName: string): void
```

### Theme Validation
```javascript
// validateTheme(themeJson: object): { valid: boolean, errors: string[] }
// - Checks required fields
// - Validates color hex formats
// - Validates font URL accessibility (optional)
// - Checks id uniqueness across all themes
// - Validates preview colors
```

### inject.js Browser API
```javascript
// Injected into Claude web UI. Exposes:
// window.__CLAUDE_THEME__ = {
//   applyTokens(tokens): void,
//   reset(): void,
//   getActiveTheme(): Theme|null,
//   version: "1.0.0"
// }
```

## 9. Security Constraints

- **Zero npm dependencies**: No package.json dependencies in core engine
- **Zero external build tools**: No webpack, postcss, tailwind, etc.
- **Native APIs only**: fs, path, CSSStyleSheet, MutationObserver, FontFace
- **CSP friendly**: Extension injects no inline scripts beyond its own
- **No network calls from CLI**: All network requests happen in browser context only
- **Auditable**: All code is human-readable JavaScript with no transpilation step
